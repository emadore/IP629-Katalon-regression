<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>000_instructions_01_3.0-area-title_fr</name>
   <tag></tag>
   <elementGuidId>8448db54-e92d-4ce2-b58b-64413812dc65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//dd[@id='fn1']/p[9]/strong</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Sauvegarder le fichier XML' or . = 'Sauvegarder le fichier XML')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(9) > strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=note >> internal:text=&quot;Sauvegarder le fichier XML&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>ce020bc9-be74-4e59-855c-15c8bc6ad0ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sauvegarder le fichier XML</value>
      <webElementGuid>4fd316e2-9294-437a-a7d1-51772d2ddab8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;fn1&quot;)/p[9]/strong[1]</value>
      <webElementGuid>668900b0-6262-4dea-b53d-857f1d456ac6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//dd[@id='fn1']/p[9]/strong</value>
      <webElementGuid>efefb8d0-8013-45ca-a2d2-2663ab315d91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Charger un fichier XML'])[1]/following::strong[1]</value>
      <webElementGuid>52b7d272-32ca-4c9a-861d-e082631b4010</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Créer une nouveau dossier'])[1]/following::strong[2]</value>
      <webElementGuid>26ddadcd-01dd-4ae6-8df1-cd3c527dd710</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exporter le dossier'])[1]/preceding::strong[1]</value>
      <webElementGuid>fe870b76-f87a-46e1-bbea-03ae895d1c3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retour à la directive'])[1]/preceding::strong[2]</value>
      <webElementGuid>4eb627fd-32da-4c15-b500-5054e8e1bcd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sauvegarder le fichier XML']/parent::*</value>
      <webElementGuid>8a36fcc0-4ff6-4e77-8774-789b1336aa0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[9]/strong</value>
      <webElementGuid>0bc48ab3-64e3-4e39-8cf4-f7b9d29cbf01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Sauvegarder le fichier XML' or . = 'Sauvegarder le fichier XML')]</value>
      <webElementGuid>3bc452bb-c2fb-4abe-89ca-f55074b7d4c3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
