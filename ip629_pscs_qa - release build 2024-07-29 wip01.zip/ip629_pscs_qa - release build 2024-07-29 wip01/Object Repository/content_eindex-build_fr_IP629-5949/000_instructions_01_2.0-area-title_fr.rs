<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>000_instructions_01_2.0-area-title_fr</name>
   <tag></tag>
   <elementGuidId>511fc9da-d9ea-424c-99c6-a00e06f23980</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//dd[@id='fn1']/p[7]/strong</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Charger un fichier XML' or . = 'Charger un fichier XML')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(7) > strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=note >> internal:text=&quot;Charger un fichier XML&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>af57d4e9-ca03-473f-9206-a6254c8fbe03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Charger un fichier XML</value>
      <webElementGuid>7c05ce49-d276-4143-bd8a-b182bc473709</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;fn1&quot;)/p[7]/strong[1]</value>
      <webElementGuid>10132d8f-550a-45f1-aeeb-814cf249fb8a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//dd[@id='fn1']/p[7]/strong</value>
      <webElementGuid>28bb9d10-2baf-4236-963b-b183d4dc72b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Créer une nouveau dossier'])[1]/following::strong[1]</value>
      <webElementGuid>7a48c867-af78-4d92-8b95-991e2f0ec530</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive 1'])[1]/following::strong[2]</value>
      <webElementGuid>e32d4104-26b7-4dbe-b9a1-2c654e206efe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sauvegarder le fichier XML'])[1]/preceding::strong[1]</value>
      <webElementGuid>08b3d157-21c6-4e33-8836-aa1e3654f74e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exporter le dossier'])[1]/preceding::strong[2]</value>
      <webElementGuid>974160ff-f256-4f25-a80a-9d00afab8dd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Charger un fichier XML']/parent::*</value>
      <webElementGuid>17be6176-68f0-4228-b12e-d6969284da8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[7]/strong</value>
      <webElementGuid>de6aefbe-6499-40d8-9b0d-297077817062</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Charger un fichier XML' or . = 'Charger un fichier XML')]</value>
      <webElementGuid>829b03b9-4b73-43c7-ad56-b6cdaf5c94c9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
