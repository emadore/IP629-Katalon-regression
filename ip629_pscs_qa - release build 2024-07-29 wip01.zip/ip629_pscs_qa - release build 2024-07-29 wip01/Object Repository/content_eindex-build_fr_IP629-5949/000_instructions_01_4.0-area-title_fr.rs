<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>000_instructions_01_4.0-area-title_fr</name>
   <tag></tag>
   <elementGuidId>25962a29-bf3b-43e1-8400-08da4eca3843</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//dd[@id='fn1']/p[12]/strong</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Exporter le dossier' or . = 'Exporter le dossier')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(12) > strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Exporter le dossier&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>9b8b43c2-18d5-4f96-bee8-273633eceb3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Exporter le dossier</value>
      <webElementGuid>77fda04e-348f-41b3-8fbd-95d5ed8e8a3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;fn1&quot;)/p[12]/strong[1]</value>
      <webElementGuid>ab6b95e1-8f57-47f3-a78b-b74a0548bfce</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//dd[@id='fn1']/p[12]/strong</value>
      <webElementGuid>af6f6fde-b3ed-4875-ba6e-4ba0055d5e10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sauvegarder le fichier XML'])[1]/following::strong[1]</value>
      <webElementGuid>43cd0317-4858-4713-b1e0-3a7a5d0d0b1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Charger un fichier XML'])[1]/following::strong[2]</value>
      <webElementGuid>740d079e-e084-42b0-9b68-439269f9f811</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retour à la directive'])[1]/preceding::strong[1]</value>
      <webElementGuid>19e1d83d-cb1d-44ce-8f47-78066e4f03a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive 2'])[1]/preceding::strong[1]</value>
      <webElementGuid>d3bb7a21-d1d4-4213-b843-18b585dce9f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Exporter le dossier']/parent::*</value>
      <webElementGuid>018d9234-c513-4555-af01-4ee818be2707</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[12]/strong</value>
      <webElementGuid>2aa6af26-a46f-4192-85a1-da479c1a65c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Exporter le dossier' or . = 'Exporter le dossier')]</value>
      <webElementGuid>9a6a9348-b062-4982-b0b3-8a5a7ddea714</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
