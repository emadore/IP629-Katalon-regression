<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>000_instructions_05_1.0-area-title_fr</name>
   <tag></tag>
   <elementGuidId>ba7015a3-cca2-44ac-84a3-a57fcef579a1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//dd[@id='fn5']/p/strong</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Code(s) de numérotation des données' or . = 'Code(s) de numérotation des données')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#fn5 > p > strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=note >> internal:text=&quot;Code(s) de numérotation des données&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>cb68902e-ff84-41a9-8550-6bb68739cd7a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Code(s) de numérotation des données</value>
      <webElementGuid>d1de352f-1305-4442-a79e-8db77746046a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;fn5&quot;)/p[1]/strong[1]</value>
      <webElementGuid>7030c4fd-be7e-4854-a916-8cc56fa6e9f3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//dd[@id='fn5']/p/strong</value>
      <webElementGuid>aef6a896-3bfd-43a5-9a3a-f0ce3bf1057b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive 5'])[1]/following::strong[1]</value>
      <webElementGuid>2a8c578e-c0d3-4e95-8621-953c04b503a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retour à la directive'])[4]/following::strong[1]</value>
      <webElementGuid>f2ae85b3-7970-4ee3-aa29-9906928237ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Disponible'])[1]/preceding::strong[1]</value>
      <webElementGuid>82ddb3a8-15ad-4683-80ad-146652095fd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sélectionné'])[1]/preceding::strong[2]</value>
      <webElementGuid>8083658f-6e2e-459d-a352-42f4e6980204</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Code(s) de numérotation des données']/parent::*</value>
      <webElementGuid>83eb4e48-cc60-440b-8de8-65adc7bb4992</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dd[5]/p/strong</value>
      <webElementGuid>f8f99bbd-8566-4892-9823-fd8d5be3ea66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Code(s) de numérotation des données' or . = 'Code(s) de numérotation des données')]</value>
      <webElementGuid>1d03a7a5-35c3-4f88-bdd0-4052528ccdf9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
