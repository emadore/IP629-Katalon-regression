<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>000_instructions_05_1.4_fr</name>
   <tag></tag>
   <elementGuidId>b3176d4c-b722-4d19-9f1f-67bece9e84a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//dd[@id='fn5']/p[5]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélectionné pour chaque document puisque ceux-ci ne peuvent être combinés avec nul autre code.' or . = 'Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélectionné pour chaque document puisque ceux-ci ne peuvent être combinés avec nul autre code.')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#fn5 > p:nth-of-type(5)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélect&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>34cd0699-6d6a-4992-aea3-9c0025379aac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélectionné pour chaque document puisque ceux-ci ne peuvent être combinés avec nul autre code.</value>
      <webElementGuid>aec98c57-3a77-4fc6-8534-88ac1b58a19c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;fn5&quot;)/p[5]</value>
      <webElementGuid>f62623b1-bbf8-4b66-9a55-0e17913222f2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//dd[@id='fn5']/p[5]</value>
      <webElementGuid>0dc6ebba-5e98-48d0-aa4c-1b98d0b08315</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Code(s) de numérotation des données'])[1]/following::p[4]</value>
      <webElementGuid>1e5980ac-51a5-4090-9159-3a2a2fe2e869</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive 5'])[1]/following::p[5]</value>
      <webElementGuid>b40dba46-472f-4bcf-8fd2-808791cade94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Disponible'])[1]/preceding::p[1]</value>
      <webElementGuid>63143e93-fec4-4991-a709-4ec8c9550f2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sélectionné'])[1]/preceding::p[3]</value>
      <webElementGuid>cce67313-8ac9-4722-94ce-69fdc1f11904</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélectionné pour chaque document puisque ceux-ci ne peuvent être combinés avec nul autre code.']/parent::*</value>
      <webElementGuid>243cdf34-b7d5-4fcc-915a-86fddafef180</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dd[5]/p[5]</value>
      <webElementGuid>06278c4d-c268-4e96-b184-e24565412bc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélectionné pour chaque document puisque ceux-ci ne peuvent être combinés avec nul autre code.' or . = 'Pour les CODOs qui commencent avec un O. ou un 1., seul un code peut être sélectionné pour chaque document puisque ceux-ci ne peuvent être combinés avec nul autre code.')]</value>
      <webElementGuid>83102115-387d-4cd4-9a9a-71e24ef9df8d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
