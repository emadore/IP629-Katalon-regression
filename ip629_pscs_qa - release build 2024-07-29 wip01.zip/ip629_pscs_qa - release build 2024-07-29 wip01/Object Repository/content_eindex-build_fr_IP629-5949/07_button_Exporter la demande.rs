<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>07_button_Exporter la demande</name>
   <tag></tag>
   <elementGuidId>797b139c-05ce-4a1a-9e71-524c17de7f73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='eibldr-builder-sec-1']/div/div/div[2]/button[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Exporter la demande&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>e53bbc71-db1a-4834-bd49-d2607681d6d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default</value>
      <webElementGuid>f23f59ca-29c0-4e32-b4fd-f8c34a62f23a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Exporter la demande</value>
      <webElementGuid>7ca5ca6d-b79a-49eb-b238-47ebcc18fd42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;eibldr-builder-sec-1&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;col-md-7 text-right&quot;]/button[@class=&quot;btn btn-default&quot;]</value>
      <webElementGuid>35219fac-cdc1-4f33-9bb1-c9af6cfb4ccf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='eibldr-builder-sec-1']/div/div/div[2]/button[4]</value>
      <webElementGuid>e0ed5a8e-1b49-4a79-9ef6-71fac1150496</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sauvegarder le fichier XML'])[3]/following::button[1]</value>
      <webElementGuid>379f90b5-12db-4182-ae77-95d6f571a8d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Charger un fichier XML'])[3]/following::button[2]</value>
      <webElementGuid>ffd8158d-7b39-4a84-9400-38fbe9cb3436</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive'])[1]/preceding::button[1]</value>
      <webElementGuid>6af44ea3-467e-40e5-a9cd-dc807039cbe7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ajouter un nouvel enregistrement'])[2]/preceding::button[1]</value>
      <webElementGuid>9d07890d-37fc-4745-9032-c1614bb5c0cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/button[4]</value>
      <webElementGuid>28436d3a-804b-4731-b451-0832100683a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Exporter la demande' or . = 'Exporter la demande')]</value>
      <webElementGuid>27200014-f23f-496f-829e-7da79790eb45</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
