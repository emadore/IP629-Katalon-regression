<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>000_instructions_03_1.1-area_fr</name>
   <tag></tag>
   <elementGuidId>53ea1131-4d26-4949-9386-0bdc831608ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//dd[@id='fn3']/p</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Sélectionner le document à modifier.' or . = 'Sélectionner le document à modifier.')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#fn3 > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Sélectionner le document à modifier.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>5b9983e6-0368-44e1-ae07-09f6803bb4c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sélectionner le document à modifier.</value>
      <webElementGuid>c0ffee6b-a46e-4893-985c-0f2b41834a4a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;fn3&quot;)/p[1]</value>
      <webElementGuid>50003b92-ab15-40bf-9915-58f995059b0a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//dd[@id='fn3']/p</value>
      <webElementGuid>b159a878-8028-4766-835c-dac8c2d2ebd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive 3'])[1]/following::p[1]</value>
      <webElementGuid>a761a47c-9117-4327-b842-0fd0ee61b903</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retour à la directive'])[2]/following::p[1]</value>
      <webElementGuid>00c20aaa-f0cc-411d-977a-8894bb9df6b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retour à la directive'])[3]/preceding::p[1]</value>
      <webElementGuid>8aa2aff7-ce6f-4c4b-a532-2f975e563a07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directive 4'])[1]/preceding::p[2]</value>
      <webElementGuid>95f515d0-a017-4c09-bf51-98b047933721</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sélectionner le document à modifier.']/parent::*</value>
      <webElementGuid>eaf83abe-1743-4ea0-8f34-b58ffd15021a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dd[3]/p</value>
      <webElementGuid>6620300c-098e-45aa-8668-5854d35fbf1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Sélectionner le document à modifier.' or . = 'Sélectionner le document à modifier.')]</value>
      <webElementGuid>b1d2364c-6933-48a0-9073-7990088b9fa2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
